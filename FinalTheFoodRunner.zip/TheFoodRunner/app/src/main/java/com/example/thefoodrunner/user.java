package com.example.thefoodrunner;

public class user {

    String resName,resLoc;

    public String getResName() {
        return resName;
    }
    public String getResLoc() {
        return resLoc;
    }
}